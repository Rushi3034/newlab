export class Appointment {
    id:number=0;
    name:string=""
    age:string=""
    symtomps:string=""
    number:string=""
}
