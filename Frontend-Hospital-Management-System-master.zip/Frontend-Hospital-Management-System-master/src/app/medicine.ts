export class Medicine {
    id:number=0;
    drugName:string="";
    stock:string="";
}
